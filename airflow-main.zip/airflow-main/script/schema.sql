DROP covidata.tabla IF EXISTS;
CREATE TABLE IF NOT EXISTS covidata.tabla(
ProvinceState VARCHAR(50),
CountryRegion VARCHAR(50),
Latitude INT,
Longitude INT,
Cantidad INT,
Estatus INT,
Mes INT,
Dia INT,
Anio INT,
CoviDate VARCHAR(25)
);