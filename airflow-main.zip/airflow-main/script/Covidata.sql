CREATE TABLE CoviData(
ProvinceState VARCHAR(50),
CountryRegion VARCHAR(50),
Latitude int,
Longitude int,
DateCovid VARCHAR(25),
Estatus int,
Cantidad int
);