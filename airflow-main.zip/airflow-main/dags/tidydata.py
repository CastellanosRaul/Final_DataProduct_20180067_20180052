import os
from airflow import DAG
from airflow.contrib.hooks.fs_hook import FSHook
from airflow.contrib.sensors.file_sensor import FileSensor
from airflow.hooks.mysql_hook import MySqlHook
from airflow.operators.python_operator import PythonOperator
from airflow.utils.dates import days_ago
from structlog import get_logger
import sqlalchemy as db
import pandas as pd
import MySQLdb

def transformacion_datos(**kwargs):
    #Se creara Status como una columna categorica para confirmado, muerto, recuperado
    #Confirmados
    confirmed = pd.read_csv('/home/airflow/monitor/time_series_covid19_confirmed_global.csv')
    confirmed = pd.melt(confirmed, id_vars=['Province/State', 'Country/Region', 'Lat', 'Long'])
    confirmed['Estatus'] = 1
    confirmed = confirmed.rename(columns={
        'Province/State': 'ProvinceState',
        'Country/Region': 'CountryRegion',
        'Lat': 'Latitude',
        'Long': 'Longitude',
        'Lat': 'Latitude',
        'variable': 'DateCovid',
        'value': 'Cantidad',
        'Estatus': 'Estatus'
    })
    fechas = confirmed["DateCovid"].str.split("/", n=2, expand=True)
    confirmed['Month'] = fechas[0]
    confirmed['Day'] = fechas[1]
    confirmed['Year'] = fechas[2]
    confirmed['CoviDate'] = "20" + confirmed['Year'] + "-" + confirmed['Month'] + "-" + confirmed['Day']
    confirmed.drop(['DateCovid'], axis='columns', inplace=True)

    #Muertes
    death = pd.read_csv('/home/airflow/monitor/time_series_covid19_deaths_global.csv')
    death = pd.melt(death, id_vars=['Province/State', 'Country/Region', 'Lat', 'Long'])
    death['Estatus'] = 2
    death = death.rename(columns={
        'Province/State': 'ProvinceState',
        'Country/Region': 'CountryRegion',
        'Lat': 'Latitude',
        'Long': 'Longitude',
        'Lat': 'Latitude',
        'variable': 'DateCovid',
        'value': 'Cantidad',
        'Estatus': 'Estatus'
    })
    fechas = death["DateCovid"].str.split("/", n=2, expand=True)
    death['Month'] = fechas[0]
    death['Day'] = fechas[1]
    death['Year'] = fechas[2]
    death['CoviDate'] = "20" + death['Year'] + "-" + death['Month'] + "-" + death['Day']
    death.drop(['DateCovid'], axis='columns', inplace=True)

    #Recuperados
    recovered = pd.read_csv('/home/airflow/monitor/time_series_covid19_recovered_global.csv')
    recovered = pd.melt(recovered, id_vars=['Province/State', 'Country/Region', 'Lat', 'Long'])
    recovered['Estatus'] = 3
    recovered = recovered.rename(columns={
        'Province/State': 'ProvinceState',
        'Country/Region': 'CountryRegion',
        'Lat': 'Latitude',
        'Long': 'Longitude',
        'Lat': 'Latitude',
        'variable': 'DateCovid',
        'value': 'Cantidad',
        'Estatus': 'Estatus'
    })
    fechas = recovered["DateCovid"].str.split("/", n=2, expand=True)
    recovered['Month'] = fechas[0]
    recovered['Day'] = fechas[1]
    recovered['Year'] = fechas[2]
    recovered['CoviDate'] = "20" + recovered['Year'] + "-" + recovered['Month'] + "-" + recovered['Day']
    recovered.drop(['DateCovid'], axis='columns', inplace=True)

    CoDeRe = pd.concat([confirmed, death, recovered])

    engine = db.create_engine("mysql://covidata:covidata@172.20.0.1:3306/covidata")
    engine.connect()
    with engine.begin() as connection:
         connection.execute("GRANT ALL PRIVILEGES ON `covidata`.* TO `covidata`@`172.20.0.1`")
         CoDeRe.to_sql('tabla', con=connection, schema='covidata', if_exists='replace', index=False)

    db = MySQLdb.connect(host="localhost", user="covidata", passwd="covidata", db="covidata")

Transformacion_DAG = DAG('TransformBaseDeDatos', description='Reading CSV files',
                default_args={
                    'owner': 'raulcastellanos',
                    'depends_on_past': False,
                    'max_active_runs': 1,
                    'start_date': days_ago(1)
                },
                schedule_interval=None,
                catchup=True)


TidyTransform = PythonOperator(
    task_id='TransformTidy',
    dag=Transformacion_DAG,
    python_callable=transformacion_datos,
    provide_context=True,
    op_kwargs={
    }
)

TidyTransform



def transformacion_confirmados(**kwargs):
    #Se creara Status como una columna categorica para confirmado, muerto, recuperado
    #Confirmados
    confirmed = pd.read_csv('/home/airflow/monitor/time_series_covid19_confirmed_global.csv')
    confirmed = pd.melt(confirmed, id_vars=['Province/State', 'Country/Region', 'Lat', 'Long'])
    confirmed['Estatus'] = 1
    confirmed = confirmed.rename(columns={
        'Province/State': 'ProvinceState',
        'Country/Region': 'CountryRegion',
        'Lat': 'Latitude',
        'Long': 'Longitude',
        'Lat': 'Latitude',
        'variable': 'DateCovid',
        'value': 'Cantidad',
        'Estatus': 'Estatus'
    })
    fechas = confirmed["DateCovid"].str.split("/", n=2, expand=True)
    confirmed['Month'] = fechas[0]
    confirmed['Day'] = fechas[1]
    confirmed['Year'] = fechas[2]
    confirmed['CoviDate'] = "20" + confirmed['Year'] + "-" + confirmed['Month'] + "-" + confirmed['Day']
    confirmed.drop(['DateCovid'], axis='columns', inplace=True)

    path = '/home/airflow/monitor/'
    confirmed.to_csv(path+"tidyconfirmed.csv")

Confirmados_DAG = DAG('TransformConfirmados', description='Reading CSV files',
                default_args={
                    'owner': 'raulcastellanos',
                    'depends_on_past': False,
                    'max_active_runs': 1,
                    'start_date': days_ago(1)
                },
                schedule_interval=None,
                catchup=True)


Confirmados1 = PythonOperator(
    task_id='TidyConfirmados',
    dag=Confirmados_DAG,
    python_callable=transformacion_confirmados,
    provide_context=True,
    op_kwargs={
    }
)

Confirmados1

def transformacion_Muertos(**kwargs):
    #Se creara Status como una columna categorica para confirmado, muerto, recuperado
    #Muertes
    death = pd.read_csv('/home/airflow/monitor/time_series_covid19_deaths_global.csv')
    death = pd.melt(death, id_vars=['Province/State', 'Country/Region', 'Lat', 'Long'])
    death['Estatus'] = 2
    death = death.rename(columns={
        'Province/State': 'ProvinceState',
        'Country/Region': 'CountryRegion',
        'Lat': 'Latitude',
        'Long': 'Longitude',
        'Lat': 'Latitude',
        'variable': 'DateCovid',
        'value': 'Cantidad',
        'Estatus': 'Estatus'
    })
    fechas = death["DateCovid"].str.split("/", n=2, expand=True)
    death['Month'] = fechas[0]
    death['Day'] = fechas[1]
    death['Year'] = fechas[2]
    death['CoviDate'] = "20" + death['Year'] + "-" + death['Month'] + "-" + death['Day']
    death.drop(['DateCovid'], axis='columns', inplace=True)

    path = '/home/airflow/monitor/'
    death.to_csv(path+"tidydeath.csv")

Muertos_DAG = DAG('TransformMuertos', description='Reading CSV files',
                default_args={
                    'owner': 'raulcastellanos',
                    'depends_on_past': False,
                    'max_active_runs': 1,
                    'start_date': days_ago(1)
                },
                schedule_interval=None,
                catchup=True)

Muertos1 = PythonOperator(
    task_id='TidyMuertos',
    dag=Muertos_DAG,
    python_callable=transformacion_Muertos,
    provide_context=True,
    op_kwargs={
    }
)

Muertos1

def transformacion_Recuperados(**kwargs):
    #Se creara Status como una columna categorica para confirmado, muerto, recuperado
    #Confirmados

    #Recuperados
    recovered = pd.read_csv('/home/airflow/monitor/time_series_covid19_recovered_global.csv')
    recovered = pd.melt(recovered, id_vars=['Province/State', 'Country/Region', 'Lat', 'Long'])
    recovered['Estatus'] = 3
    recovered = recovered.rename(columns={
        'Province/State': 'ProvinceState',
        'Country/Region': 'CountryRegion',
        'Lat': 'Latitude',
        'Long': 'Longitude',
        'Lat': 'Latitude',
        'variable': 'DateCovid',
        'value': 'Cantidad',
        'Estatus': 'Estatus'
    })
    fechas = recovered["DateCovid"].str.split("/", n=2, expand=True)
    recovered['Month'] = fechas[0]
    recovered['Day'] = fechas[1]
    recovered['Year'] = fechas[2]
    recovered['CoviDate'] = "20" + recovered['Year'] + "-" + recovered['Month'] + "-" + recovered['Day']
    recovered.drop(['DateCovid'], axis='columns', inplace=True)

    path = '/home/airflow/monitor/'
    recovered.to_csv(path+"tidyrecovered.csv")

Recuperados_DAG = DAG('TransformTRecuperados', description='Reading CSV files',
                default_args={
                    'owner': 'raulcastellanos',
                    'depends_on_past': False,
                    'max_active_runs': 1,
                    'start_date': days_ago(1)
                },
                schedule_interval=None,
                catchup=True)


Recuperados1 = PythonOperator(
    task_id='TidyRecuperados',
    dag=Recuperados_DAG,
    python_callable=transformacion_Recuperados,
    provide_context=True,
    op_kwargs={
    }
)

Recuperados1
